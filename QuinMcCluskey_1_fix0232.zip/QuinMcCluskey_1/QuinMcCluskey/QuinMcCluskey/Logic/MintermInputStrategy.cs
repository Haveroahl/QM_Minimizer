﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuinMcCluskey.Logic
{
    public class MintermInputStrategy : IInputStrategy
    {
        private readonly HashSet<int> _terms;
        public MintermInputStrategy(HashSet<int> terms = null)
        {
            _terms = terms ?? new HashSet<int>();
        }
        public HashSet<int> GetTerms(int numVariables, HashSet<int> dontCares)
        {
            ValidateInput(numVariables, _terms, dontCares);
            return _terms;
        }
        private void ValidateInput(int numVariables, HashSet<int> terms, HashSet<int> dontCares)
        {
            int maxValue = (1 << numVariables) - 1;
            foreach (var term in terms)
            {
                if (term < 0 || term > maxValue)
                    throw new ArgumentException($"Minterm {term} không hợp lệ với {numVariables} biến.");
            }
        }
    }
}
