﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuinMcCluskey.Logic
{
    public static class MinimizerFactory
    {
        public static IBooleanFunctionMinimizer CreateMinimizer(int numVariables, IInputStrategy inputStrategy, HashSet<int> dontCares, bool isMintermInput)
        {
            HashSet<int> terms = inputStrategy.GetTerms(numVariables, dontCares);
            return new QuineMcCluskeyMinimizer(numVariables, terms, dontCares, isMintermInput);
        }
    }
}
