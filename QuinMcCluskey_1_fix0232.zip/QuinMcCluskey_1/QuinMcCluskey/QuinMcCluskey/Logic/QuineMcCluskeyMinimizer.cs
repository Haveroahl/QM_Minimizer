﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuinMcCluskey.Logic
{
   public class QuineMcCluskeyMinimizer : BooleanFunctionMinimizer
    {
        private readonly bool isMintermInput; // Xác định loại đầu vào: true = minterms, false = maxterms

        public QuineMcCluskeyMinimizer(int numVariables, HashSet<int>? terms, HashSet<int>? dontCares, bool isMintermInput)
            : base(numVariables, terms, dontCares)
        {
            this.isMintermInput = isMintermInput;
        }

        public override string Minimize()
        {
            return isMintermInput ? MinimizeSOP() : MinimizePOS();
        }

        private string MinimizeSOP()
        {
            int maxValue = (1 << NumVariables) - 1;

            if (Terms.Union(DontCares).Count() == maxValue + 1)
                return "1";

            if (!Terms.Any())
                return "0";

            HashSet<int> allTerms = new HashSet<int>(Terms);
            allTerms.UnionWith(DontCares);
            List<string> binaryTerms = allTerms.Select(m => Convert.ToString(m, 2).PadLeft(NumVariables, '0')).ToList();
            HashSet<string> primeImplicants = FindPrimeImplicants(binaryTerms);
            HashSet<string> essentialPrimeImplicants = ExtractEssentialPrimeImplicants(primeImplicants, Terms, ConvertToVariablesSOP);

            return essentialPrimeImplicants.Any() ? string.Join(" + ", essentialPrimeImplicants) : "0";
        }

        private string MinimizePOS()
        {
            int maxValue = (1 << NumVariables) - 1;

            if (Terms.Union(DontCares).Count() == maxValue + 1)
                return "0";

            if (!Terms.Any())
                return "1";

            HashSet<int> allTerms = new HashSet<int>(Terms); // Maxterms
            allTerms.UnionWith(DontCares);
            List<string> binaryTerms = allTerms.Select(m => Convert.ToString(m, 2).PadLeft(NumVariables, '0')).ToList();
            HashSet<string> primeImplicants = FindPrimeImplicants(binaryTerms);
            HashSet<string> essentialPrimeImplicants = ExtractEssentialPrimeImplicants(primeImplicants, Terms, ConvertToVariablesPOS);

            if (!essentialPrimeImplicants.Any())
                return "1";

            return string.Join("", essentialPrimeImplicants.Select(implicant => $"({implicant})"));
        }


        private HashSet<string> FindPrimeImplicants(List<string> binaryTerms)
        {
            HashSet<string> primeImplicants = new HashSet<string>();
            Dictionary<int, List<string>> termsByOnes = new Dictionary<int, List<string>>();

            foreach (var term in binaryTerms)
            {
                int onesCount = term.Count(c => c == '1');
                if (!termsByOnes.ContainsKey(onesCount))
                    termsByOnes[onesCount] = new List<string>();
                termsByOnes[onesCount].Add(term);
            }

            HashSet<string> currentTerms = new HashSet<string>(binaryTerms);
            HashSet<string> alreadyCombined = new();

            for (int i = 0; i < NumVariables; i++)
            {
                HashSet<string> newTerms = new HashSet<string>();
                alreadyCombined.Clear();

                foreach (var group in termsByOnes.OrderBy(kv => kv.Key).ToList())
                {
                    int onesCount = group.Key;
                    if (!termsByOnes.ContainsKey(onesCount + 1)) continue;

                    foreach (var term1 in group.Value)
                    {
                        foreach (var term2 in termsByOnes[onesCount + 1])
                        {
                            string? combinedTerm = Combine(term1, term2);
                            if (combinedTerm != null)
                            {
                                newTerms.Add(combinedTerm);
                                alreadyCombined.Add(term1);
                                alreadyCombined.Add(term2);
                            }
                        }
                    }
                }

                foreach (var term in currentTerms)
                {
                    if (!alreadyCombined.Contains(term))
                        primeImplicants.Add(term);
                }

                if (newTerms.Count == 0) break;
                currentTerms = newTerms;

                // Cập nhật lại termsByOnes
                termsByOnes.Clear();
                foreach (var term in currentTerms)
                {
                    int onesCount = term.Count(c => c == '1');
                    if (!termsByOnes.ContainsKey(onesCount))
                        termsByOnes[onesCount] = new List<string>();
                    termsByOnes[onesCount].Add(term);
                }
            }

            primeImplicants.UnionWith(currentTerms);
            return primeImplicants;
        }


        private string? Combine(string a, string b)
        {
            int diffCount = 0;
            char[] result = new char[a.Length];

            for (int i = 0; i < a.Length; i++)
            {
                if (a[i] != b[i])
                {
                    diffCount++;
                    result[i] = '-';
                }
                else
                {
                    result[i] = a[i];
                }

                if (diffCount > 1)
                    return null;
            }

            return new string(result);
        }

        private HashSet<string> ExtractEssentialPrimeImplicants(HashSet<string> primeImplicants, HashSet<int> terms, Func<string, string> convertToVariables)
        {
            if (!primeImplicants.Any() || !terms.Any())
                return new HashSet<string>();

            var chart = new Dictionary<string, HashSet<int>>();
            foreach (var implicant in primeImplicants)
            {
                chart[implicant] = new HashSet<int>();
                foreach (var term in terms)
                {
                    if (Covers(implicant, Convert.ToString(term, 2).PadLeft(NumVariables, '0')))
                        chart[implicant].Add(term);
                }
            }

            var essentialPrimeImplicants = new HashSet<string>();
            var coveredTerms = new HashSet<int>();

            foreach (var term in terms)
            {
                var coveringImplicants = chart.Where(c => c.Value.Contains(term)).Select(c => c.Key).ToList();
                if (coveringImplicants.Count == 1)
                {
                    var essentialImplicant = coveringImplicants.First();
                    essentialPrimeImplicants.Add(essentialImplicant);
                    coveredTerms.UnionWith(chart[essentialImplicant]);
                }
            }

            var remainingTerms = terms.Except(coveredTerms).ToHashSet();
            while (remainingTerms.Count > 0)
            {
                var bestImplicant = chart
                    .Where(c => !essentialPrimeImplicants.Contains(c.Key))
                    .OrderByDescending(c => c.Value.Intersect(remainingTerms).Count())
                    .FirstOrDefault();

                if (bestImplicant.Key == null) break;

                essentialPrimeImplicants.Add(bestImplicant.Key);
                coveredTerms.UnionWith(bestImplicant.Value);
                remainingTerms = terms.Except(coveredTerms).ToHashSet();
            }

            return new HashSet<string>(essentialPrimeImplicants.Select(convertToVariables));
        }

        private bool Covers(string implicant, string term)
        {
            for (int i = 0; i < implicant.Length; i++)
            {
                if (implicant[i] != '-' && implicant[i] != term[i])
                    return false;
            }
            return true;
        }

        private string ConvertToVariablesSOP(string term)
        {
            if (string.IsNullOrEmpty(term))
                return string.Empty;

            HashSet<string> variables = GenerateVariableNames(NumVariables);
            List<string> result = new List<string>();

            for (int i = 0; i < term.Length; i++)
            {
                if (term[i] == '1')
                    result.Add(variables.ElementAt(i));
                else if (term[i] == '0')
                    result.Add(variables.ElementAt(i) + "'");
            }

            return string.Join("", result);
        }

        private string ConvertToVariablesPOS(string term)
        {
            if (string.IsNullOrEmpty(term))
                return string.Empty;

            HashSet<string> variables = GenerateVariableNames(NumVariables);
            List<string> result = new List<string>();

            for (int i = 0; i < term.Length; i++)
            {
                if (term[i] == '0')
                    result.Add(variables.ElementAt(i));
                else if (term[i] == '1')
                    result.Add(variables.ElementAt(i) + "'");
            }

            return string.Join("+", result);
        }
    }
}
