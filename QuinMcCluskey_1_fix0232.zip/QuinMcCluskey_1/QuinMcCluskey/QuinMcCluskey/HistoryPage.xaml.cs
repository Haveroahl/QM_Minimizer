﻿using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Navigation;
using QuinMcCluskey.Models;
using System.Diagnostics;
using System;

namespace QuinMcCluskey
{
    public sealed partial class HistoryPage : Page
    {
        public HistoryPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            try
            {
                HistoryListView.ItemsSource = HistoryManager.GetHistory();
                Debug.WriteLine("HistoryPage: Loaded history successfully.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"HistoryPage: Error loading history: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MainPage));
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                HistoryManager.ClearHistory();
                HistoryListView.ItemsSource = HistoryManager.GetHistory();
                Debug.WriteLine("HistoryPage: Cleared history successfully.");
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"HistoryPage: Error clearing history: {ex.Message}");
            }
        }

        private void PinButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sender is Button button && button.Tag is string operation)
                {
                    if (HistoryManager.IsPinned(operation))
                    {
                        HistoryManager.UnpinOperation(operation);
                        Debug.WriteLine($"HistoryPage: Unpinned operation: {operation}");
                    }
                    else
                    {
                        HistoryManager.PinOperation(operation);
                        Debug.WriteLine($"HistoryPage: Pinned operation: {operation}");
                    }
                    HistoryListView.ItemsSource = HistoryManager.GetHistory();
                }
                else
                {
                    Debug.WriteLine("HistoryPage: PinButton_Click - Invalid button or tag.");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"HistoryPage: Error in PinButton_Click: {ex.Message}");
            }
        }
    }

    public class PinnedVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            try
            {
                if (value is bool isPinned)
                {
                    return isPinned ? Visibility.Visible : Visibility.Collapsed;
                }
                Debug.WriteLine($"PinnedVisibilityConverter: Invalid value type: {value?.GetType().Name}");
                return Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PinnedVisibilityConverter: Error: {ex.Message}");
                return Visibility.Collapsed;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }

    public class PinButtonContentConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, string language)
        {
            try
            {
                if (value is bool isPinned)
                {
                    return isPinned ? "Unpin" : "Pin";
                }
                Debug.WriteLine($"PinButtonContentConverter: Invalid value type: {value?.GetType().Name}");
                return "Pin";
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"PinButtonContentConverter: Error: {ex.Message}");
                return "Pin";
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            throw new NotImplementedException();
        }
    }
}