﻿using System;
using System.Collections.Generic;
using System.Linq;
using Windows.Storage;

namespace QuinMcCluskey.Models
{
    public class HistoryItem
    {
        public string Operation { get; set; }
        public bool IsPinned { get; set; }
    }

    public static class HistoryManager
    {
        private static List<string> History { get; } = new List<string>();
        private static List<string> PinnedHistory { get; } = new List<string>();
        private const string PinnedHistoryKey = "PinnedHistory";

        static HistoryManager()
        {
            var localSettings = ApplicationData.Current.LocalSettings;
            if (localSettings.Values[PinnedHistoryKey] is string pinnedData)
            {
                PinnedHistory.AddRange(pinnedData.Split('|', StringSplitOptions.RemoveEmptyEntries));
            }
        }

        public static void AddOperation(string operation)
        {
            History.Add(operation);
        }

        public static void PinOperation(string operation)
        {
            if (!PinnedHistory.Contains(operation))
            {
                PinnedHistory.Add(operation);
                SavePinnedHistory();
            }
        }

        public static void UnpinOperation(string operation)
        {
            if (PinnedHistory.Remove(operation))
            {
                SavePinnedHistory();
            }
        }

        public static List<HistoryItem> GetHistory()
        {
            var combinedHistory = new List<HistoryItem>();
            combinedHistory.AddRange(PinnedHistory.Select(op => new HistoryItem { Operation = op, IsPinned = true }));
            combinedHistory.AddRange(History.Select(op => new HistoryItem { Operation = op, IsPinned = false }));
            return combinedHistory;
        }

        public static bool IsPinned(string operation)
        {
            return PinnedHistory.Contains(operation);
        }

        public static void ClearHistory()
        {
            History.Clear();
        }

        private static void SavePinnedHistory()
        {
            var localSettings = ApplicationData.Current.LocalSettings;
            localSettings.Values[PinnedHistoryKey] = string.Join("|", PinnedHistory);
        }
    }
}