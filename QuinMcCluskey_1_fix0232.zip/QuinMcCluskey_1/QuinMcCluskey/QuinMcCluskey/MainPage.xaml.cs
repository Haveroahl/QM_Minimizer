﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using QuinMcCluskey.Logic;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using QuinMcCluskey.Models;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace QuinMcCluskey
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Validate number of variables
                if (!int.TryParse(NumVariablesTextBox.Text, out int numVariables) || numVariables < 1 || numVariables > 31)
                {
                    ResultTextBlock.Text = "Error: Number of variables must be between 1 and 31.";
                    return;
                }

                // Determine input type
                bool isMintermInput = InputTypeComboBox.SelectedIndex == 0;
                IInputStrategy inputStrategy = isMintermInput ? new MintermInputStrategy() : new MaxtermInputStrategy();

                // Parse terms
                HashSet<int> terms = ParseInput(TermsTextBox.Text, numVariables, "Terms");
                if (terms == null) return;

                // Parse don't cares
                HashSet<int> dontCares = ParseInput(DontCaresTextBox.Text, numVariables, "Don't Cares", allowEmpty: true);
                if (dontCares == null) return;

                // Create minimizer
                IBooleanFunctionMinimizer minimizer = MinimizerFactory.CreateMinimizer(numVariables, new UIInputStrategy(terms), dontCares, isMintermInput);

                // Get result
                string result = minimizer.Minimize();
                string resultText = $"Result: Y = {result}";
                ResultTextBlock.Text = resultText;
                string operation = $"{numVariables} variables, {(isMintermInput ? "Minterms" : "Maxterms")}: {TermsTextBox.Text}, Don't-cares: {DontCaresTextBox.Text}, {resultText}";
                HistoryManager.AddOperation(operation);
            }
            catch (ArgumentException ex)
            {
                ResultTextBlock.Text = $"Error: {ex.Message}";
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = $"Unexpected error: {ex.Message}";
            }
        }
        private void HistoryButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(HistoryPage));
        }

        private HashSet<int> ParseInput(string input, int numVariables, string inputName, bool allowEmpty = false)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                if (allowEmpty) return new HashSet<int>();
                ResultTextBlock.Text = $"Error: {inputName} cannot be empty.";
                return null;
            }

            try
            {
                var terms = input.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .Select(int.Parse)
                    .ToHashSet();
                int maxValue = (1 << numVariables) - 1;
                foreach (var term in terms)
                {
                    if (term < 0 || term > maxValue)
                    {
                        ResultTextBlock.Text = $"Error: {inputName} value {term} is invalid for {numVariables} variables.";
                        return null;
                    }
                }
                return terms;
            }
            catch (FormatException)
            {
                ResultTextBlock.Text = $"Error: {inputName} must contain valid integers separated by spaces.";
                return null;
            }
        }

        private class UIInputStrategy : IInputStrategy
        {
            private readonly HashSet<int> _terms;

            public UIInputStrategy(HashSet<int> terms)
            {
                _terms = terms;
            }

            public HashSet<int> GetTerms(int numVariables, HashSet<int> dontCares) => _terms;
        }

      
    }

}


