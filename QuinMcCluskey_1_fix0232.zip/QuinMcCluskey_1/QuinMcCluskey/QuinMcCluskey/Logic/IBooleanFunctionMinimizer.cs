﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuinMcCluskey.Logic
{
    public interface IBooleanFunctionMinimizer
    {
        string Minimize();
    }
}
