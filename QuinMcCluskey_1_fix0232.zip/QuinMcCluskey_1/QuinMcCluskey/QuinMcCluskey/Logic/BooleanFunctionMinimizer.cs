﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuinMcCluskey.Logic
{
    public abstract class BooleanFunctionMinimizer : IBooleanFunctionMinimizer
    {
        protected int NumVariables { get; }
        protected HashSet<int> Terms { get; } // Có thể là minterms hoặc maxterms
        protected HashSet<int> DontCares { get; }

        protected BooleanFunctionMinimizer(int numVariables, HashSet<int>? terms, HashSet<int>? dontCares)
        {
            if (numVariables < 1 || numVariables > 31)
                throw new ArgumentException("Số lượng biến phải từ 1 đến 31.");
            NumVariables = numVariables;
            Terms = terms ?? new HashSet<int>();
            DontCares = dontCares ?? new HashSet<int>();
        }

        public abstract string Minimize();

        protected HashSet<string> GenerateVariableNames(int numVariables)
        {
            HashSet<string> variables = new HashSet<string>();
            for (int i = 0; i < numVariables; i++)
            {
                variables.Add(((char)('A' + i)).ToString());
            }
            return variables;
        }
    }
}
